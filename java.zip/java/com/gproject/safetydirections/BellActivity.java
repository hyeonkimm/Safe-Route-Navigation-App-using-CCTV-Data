package com.gproject.safetydirections;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import com.gproject.safetydirections.databinding.ActivityBellBinding;
import com.opencsv.CSVReader;
import com.skt.Tmap.TMapGpsManager;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPOIItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class BellActivity extends AppCompatActivity implements TMapGpsManager.onLocationChangedCallback {
    ActivityBellBinding binding;

    MyPoint curPoint;
    private TMapView tMapView;
    private TMapGpsManager tMapGPS;
    ArrayList<Bell> bells = new ArrayList<Bell>();
    BellLoadingDialog loadingDialog;
    private boolean run;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBellBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Intent intent = getIntent(); //데이터 수신
        curPoint = (MyPoint) intent.getSerializableExtra("curPoint");

        tMapView = new TMapView(this);

        tMapView.setSKTMapApiKey(""); //키값 입력
        binding.linearLayoutTmap.addView(tMapView);

        //처음 세팅
        tMapView.setZoomLevel(15);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);
        tMapView.setCompassMode(true); //현재 보는 방향으로 설정
        tMapView.setIconVisibility(true);

        tMapGPS = new TMapGpsManager(this);
        tMapGPS.setMinTime(1000);
        tMapGPS.setMinDistance(5);
        tMapGPS.setProvider(TMapGpsManager.GPS_PROVIDER);

        tMapGPS.OpenGps();

        tMapView.setLocationPoint(curPoint.getLongitude(), curPoint.getLatitude());
        tMapView.setCenterPoint(curPoint.getLongitude(), curPoint.getLatitude());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);//기본 타이틀 제거
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);  //뒤로가기 버튼 생성

        binding.currentLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.setLocationPoint(curPoint.getLongitude(), curPoint.getLatitude());
                tMapView.setCenterPoint(curPoint.getLongitude(), curPoint.getLatitude());
            }
        });

        binding.zoomPlusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomIn();
            }
        });

        binding.zoomMinusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomOut();
            }
        });

        run = true;
        new Thread() {
            @Override
            public void run() {
                while(run) {
                    getCsvData();
                    mark(bells);
                }
            }
        }.start();

        //로딩창 객체 생성
        loadingDialog = new BellLoadingDialog(this);
        loadingDialog.setCancelable(false);
        //로딩창을 투명하게
        loadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        loadingDialog.show();

        tMapView.setOnClickListenerCallBack(new TMapView.OnClickListenerCallback() {
            @Override
            public boolean onPressUpEvent(ArrayList<TMapMarkerItem> arrayList, ArrayList<TMapPOIItem> arrayList1, TMapPoint tMapPoint, PointF pointF) {
                return false;
            }

            @Override
            public boolean onPressEvent(ArrayList<TMapMarkerItem> markerlist, ArrayList<TMapPOIItem> poilist, TMapPoint point, PointF pointf) {
                if (!markerlist.isEmpty()) {
                    for (int i = 0; i < markerlist.size(); i++) {
                        TMapMarkerItem item = markerlist.get(i);
                        int id = Integer.parseInt(item.getID());
                        AlertDialog.Builder helpBuilder = new AlertDialog.Builder(BellActivity.this)
                                .setTitle("안전비상벨 정보")
                                .setMessage("설치위치 : " + bells.get(id).getLocation() + "\n"
                                + "설치장소유형 : " + bells.get(id).getLocationType() + "\n"
                                + "설치주소 : " + bells.get(id).getAdress())
                                .setPositiveButton("확인", null);
                        helpBuilder.show();
                    }
                }
                return false;
            }
        });

    }

    public boolean onOptionsItemSelected(MenuItem item) { //툴바 뒤로가기
        switch (item.getItemId()) {
            case android.R.id.home:
                run = false;
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void mark(ArrayList<Bell> bells) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.marker_yellow);
        for (int i = 0; i < bells.size(); i++) {
            TMapPoint point = new TMapPoint(bells.get(i).getLatitude(), bells.get(i).getLongitude());
            TMapMarkerItem markerItem = new TMapMarkerItem();

            markerItem.setIcon(bitmap);
            markerItem.setPosition(0.5f, 1.0f);
            markerItem.setTMapPoint(point);
            tMapView.setZoomLevel(16);
            tMapView.addMarkerItem("" + i, markerItem);
        }
        loadingDialog.dismiss();
        run = false;
    }

    public void getCsvData() {
        bells.clear();
        InputStreamReader is = new InputStreamReader(getResources().openRawResource(R.raw.data_bell));
        BufferedReader reader = new BufferedReader(is);
        CSVReader read = new CSVReader(reader);
        String[] record = null;
        try {
            while ((record = read.readNext()) != null) {
                Bell bell = new Bell(record[0], record[1], record[2], Double.valueOf(record[3]), Double.valueOf(record[4]));
                bells.add(bell);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.d("csv파일", "읽기 끝");
    }

    @Override
    public void onLocationChange(Location location) {
        tMapView.setLocationPoint(location.getLongitude(), location.getLatitude());
        tMapView.setCenterPoint(location.getLongitude(), location.getLatitude());
        curPoint.setLongitude(location.getLongitude());
        curPoint.setLatitude(location.getLatitude());
    }

    @Override
    public void onDestroy( ) {
        super.onDestroy( );
        run = false;
    }
}