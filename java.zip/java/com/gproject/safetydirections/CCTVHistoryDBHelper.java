package com.gproject.safetydirections;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class CCTVHistoryDBHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "cctvHistory.db";

    public CCTVHistoryDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS cctvHistoryTBL ("
                    + "_id integer,"
                    + "listNum integer,"
                    + "institution Text,"
                    + "count integer,"
                    + "direction Text,"
                    + "latitude double,"
                    + "longitude double,"
                    + "PRIMARY KEY(_id, listNum));"); //cctv정보들 추가하기..
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS cctvHistoryTBL");
            onCreate(db);
    }
}
