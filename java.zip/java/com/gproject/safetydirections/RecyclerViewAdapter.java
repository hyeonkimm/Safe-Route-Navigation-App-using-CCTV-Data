package com.gproject.safetydirections;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.skt.Tmap.TMapPOIItem;
import com.skt.Tmap.TMapPoint;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    Context context;
    TMapPoint curTMapPoint;
    ArrayList<TMapPOIItem> POIItemLists = new ArrayList<TMapPOIItem>();
    String address;
    double distanceResult;

    public RecyclerViewAdapter(MyPoint curPoint) {
        this.curTMapPoint = new TMapPoint(curPoint.getLatitude(), curPoint.getLongitude());
    }

    public RecyclerViewAdapter(ArrayList<TMapPOIItem> list) {
        POIItemLists = list;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.item_search, parent, false);
        return new RecyclerViewAdapter.ViewHolder(view);
    }

    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {
        final TMapPOIItem item = POIItemLists.get(position);

        distanceResult = item.getDistance(curTMapPoint);

        if (distanceResult < 1000.0) {
            distanceResult = Math.round(distanceResult);
            holder.text_distance.setText(distanceResult + "m");
        } else {
            distanceResult = Math.round(distanceResult / 10) / 100.0;
            holder.text_distance.setText(distanceResult + "km");
        }

        address = item.middleAddrName + " " + item.lowerAddrName + " " + item.roadName + " " + item.buildingNo1;

        holder.location_name.setText(item.name);
        holder.location_address.setText(address);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((SearchActivity) context).setItemForIntent(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return POIItemLists.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView location_name;
        TextView location_address;
        TextView text_distance;

        ViewHolder(View itemView) {
            super(itemView);

            // 뷰 객체에 대한 참조
            location_name = itemView.findViewById(R.id.location_name);
            location_address = itemView.findViewById(R.id.location_address);
            text_distance = itemView.findViewById(R.id.text_distance);
        }
    }

    public void startNewSearch() {
        POIItemLists.clear();
        notifyDataSetChanged();
    }

    public void addItem(TMapPOIItem item) {  //TMapPOIItem POIItemLists
        POIItemLists.add(item);
    }

    public void setItems(ArrayList<TMapPOIItem> itemLists) {
        this.POIItemLists = itemLists;
    }

    public TMapPOIItem getItem(int position) {
        return POIItemLists.get(position);
    }

    public void setItem(int position, TMapPOIItem item) {
        POIItemLists.set(position, item);
    }

}
