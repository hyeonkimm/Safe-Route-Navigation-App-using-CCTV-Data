package com.gproject.safetydirections;

import com.skt.Tmap.TMapPoint;

import java.io.Serializable;

public class MyPoint implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name = "";
    private double latitude = 0.0;
    private double longitude = 0.0;

    MyPoint(){

    }

    MyPoint(String location_name, double latitude, double longitude) {
        this.name = location_name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    MyPoint(String location_name, TMapPoint tMapPoint) {
        this.name = location_name;
        this.latitude = tMapPoint.getLatitude();
        this.longitude = tMapPoint.getLongitude();
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public TMapPoint getTMapPoint() {
        TMapPoint tMapPoint = new TMapPoint(this.latitude, this.longitude);
        return tMapPoint;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
