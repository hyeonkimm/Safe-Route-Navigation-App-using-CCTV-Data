package com.gproject.safetydirections;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class RouteHistoryDBHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "routHistory.db";

    public RouteHistoryDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS routeHistoryTBL ("
                    + "_id integer,"
                    + "listNum integer,"
                    + "latitude double,"
                    + "longitude double,"
                    + "PRIMARY KEY(_id, listNum));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS routeHistoryTBL");
            onCreate(db);
    }
}
