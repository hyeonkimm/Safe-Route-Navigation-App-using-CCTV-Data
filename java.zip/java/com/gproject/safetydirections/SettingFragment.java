package com.gproject.safetydirections;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Locale;

public class SettingFragment extends PreferenceFragment implements TextToSpeech.OnInitListener {

    SharedPreferences pref;
    SwitchPreference speakPreference;
    ListPreference speedPreference;
    ListPreference pitchPreference;
    private TextToSpeech tts;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.setting);

        speakPreference = (SwitchPreference)findPreference("speak");
        speedPreference = (ListPreference)findPreference("speed");
        pitchPreference = (ListPreference)findPreference("pitch");

        pref = PreferenceManager.getDefaultSharedPreferences(getActivity());

        if(!pref.getString("speed", "").equals("")){
            speedPreference.setSummary(pref.getString("speed", "1.0") + " 배속");
        }
        if(!pref.getString("pitch", "").equals("")){
            pitchPreference.setSummary(pref.getString("pitch", "1.0"));
        }
        pref.registerOnSharedPreferenceChangeListener(listener);

        tts = new TextToSpeech(getContext(), this);
    }

    @Override
    public void onResume() {
        super.onResume();
        pref.registerOnSharedPreferenceChangeListener(listener);
    }

    @Override
    public void onPause() {
        super.onPause();
        pref.unregisterOnSharedPreferenceChangeListener(listener);
    }

    SharedPreferences.OnSharedPreferenceChangeListener listener = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            if(key.equals("speed")){
                String speed = pref.getString("speed", "1.0");
                speedPreference.setSummary(speed + " 배속");
                tts.setSpeechRate(Float.parseFloat(speed)); // 읽는 속도
                tts.speak("이정도 속도입니다", TextToSpeech.QUEUE_FLUSH, null, "speed");
            }
            if(key.equals("pitch")){
                String pitch = pref.getString("pitch", "1.0");
                pitchPreference.setSummary(pitch);
                tts.setPitch(Float.parseFloat(pitch)); // 음성 톤
                tts.speak("이정도 높낮이입니다", TextToSpeech.QUEUE_FLUSH, null, "speed");
            }
        }
    };

    public void onDestroy() {
        // TTS 객체가 남아있다면 실행을 중지하고 메모리에서 제거한다.
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.KOREA);
            tts.setSpeechRate(Float.parseFloat(pref.getString("speed", "1.0")));
            tts.setPitch(Float.parseFloat(pref.getString("pitch", "1.0"))); // 음성 톤
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "This Language is not supported");
            } else {

            }
        } else {
            Log.e("TTS", "초기화 실패");
        }
    }
}
