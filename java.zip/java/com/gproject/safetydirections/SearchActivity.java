package com.gproject.safetydirections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.gproject.safetydirections.databinding.ActivitySearchBinding;
import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapPOIItem;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    private ActivitySearchBinding binding;

    private String searchText;

    RecyclerViewAdapter adapter;
    private InputMethodManager imm;
    int intentNum = 0;
    MyPoint curPoint;

    private RecentSearchDBHelper recentSearchDBHelper;
    SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);

        recentSearchDBHelper = new RecentSearchDBHelper(this);

        Intent receiveIntent = getIntent();
        curPoint = (MyPoint) receiveIntent.getSerializableExtra("curPoint");
        try {
            intentNum = receiveIntent.getExtras().getInt("num");
        } catch (Exception e) {
            intentNum = 0;
        }

        // 리사이클러뷰
        binding.recyclerview.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerViewAdapter(curPoint);
        binding.recyclerview.setAdapter(adapter);

        binding.editSearch.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    searchText = binding.editSearch.getText().toString();
                    adapter.startNewSearch();
                    searchPOI(searchText);
                    return true;
                }
                return false;
            }
        });

        binding.searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchText = binding.editSearch.getText().toString();
                adapter.startNewSearch();
                searchPOI(searchText);
            }
        });

        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void searchPOI(String searchText) {
        TMapData tmapdata = new TMapData();

        tmapdata.findAllPOI(searchText, 50, new TMapData.FindAllPOIListenerCallback() {
            @Override
            public void onFindAllPOI(ArrayList<TMapPOIItem> poiItem) {
                for (int i = 0; i < poiItem.size(); i++) {
                    TMapPOIItem item = poiItem.get(i);

                    adapter.addItem(item);
                }
            }
        });
    }

    public void setItemForIntent(TMapPOIItem item) {
        String name = item.name;
        double latitude = item.getPOIPoint().getLatitude();
        double longitude = item.getPOIPoint().getLongitude();
        int isBM = 0;
        database = recentSearchDBHelper.getWritableDatabase();
        recentSearchDBHelper.isDuplicated(name, latitude, longitude);
        String sql = "INSERT INTO recentSearchTBL(name, latitude, longitude, isBM) VALUES(?, ?, ?, ?)";
        Log.d("데이터베이스", "넣기 성공");
        Object[] params = {name, latitude, longitude, isBM};
        database.execSQL(sql, params);

        MyPoint selectPoint = new MyPoint();

        if (intentNum == 10) {
            intentNum = 0;
            selectPoint.setName(name);
            selectPoint.setLatitude(latitude);
            selectPoint.setLongitude(longitude);
            Intent intent = new Intent(getApplicationContext(), DirectionReady.class);
            intent.putExtra("num", 10);
            intent.putExtra("curPoint", curPoint);
            intent.putExtra("selectPoint", selectPoint);
            startActivity(intent);
        } else {
            selectPoint.setName(name);
            selectPoint.setLatitude(latitude);
            selectPoint.setLongitude(longitude);
            Intent intent = new Intent();
            intent.putExtra("selectPoint", selectPoint);
            setResult(RESULT_OK, intent);
        }
        finish();
    }
}