package com.gproject.safetydirections;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Holder> {
    int num;
    Context context;
    ArrayList<MyPointForDB> list = new ArrayList<MyPointForDB>();
    RSListFragment.InnerClass rsInnerClass;
    BMListFragment.InnerClass bmInnerClass;

    Adapter(int num) {
        this.num = num;
        list = new ArrayList<MyPointForDB>();
    }

    Adapter(int num, RSListFragment.InnerClass innerClass) {
        this.num = num;
        this.rsInnerClass = innerClass;
        list = new ArrayList<MyPointForDB>();
    }

    Adapter(int num, BMListFragment.InnerClass innerClass) {
        this.num = num;
        this.bmInnerClass = innerClass;
        list = new ArrayList<MyPointForDB>();
    }

    Adapter(ArrayList<MyPointForDB> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.item, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final Holder holder, int position) {
        final MyPointForDB item = list.get(position);
        holder.textName.setText(item.getName());
        if (item.getIsBM() == 0) {
            holder.bookmarkBtn.setImageResource(R.drawable.ic_star);
        } else if (item.getIsBM() == 1) {
            holder.bookmarkBtn.setImageResource(R.drawable.ic_star_selected);
        }

        holder.bookmarkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(num == 5) {
                    rsInnerClass.clickBookMarkBtn(item);
                } else if (num == 7) {
                    bmInnerClass.clickBookMarkBtn(item);
                }
            }
        });

        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(num == 5) {
                    rsInnerClass.clickDeleteBtn(item);
                } else if (num == 7) {
                    bmInnerClass.clickDeleteBtn(item);
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(num == 5) {
                    rsInnerClass.setItemForIntent(item);
                } else if (num == 7) {
                    bmInnerClass.setItemForIntent(item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void startNew() {
        list.clear();
        notifyDataSetChanged();
    }

    public void addItem(MyPointForDB item) {
        list.add(0, item);
    }

    public void removeItem(MyPointForDB item) {
        list.remove(item);
        notifyDataSetChanged();
    }
}

class Holder extends RecyclerView.ViewHolder {
    public TextView textName;
    public ImageView bookmarkBtn;
    public ImageView deleteBtn;

    public Holder(@NonNull View itemView) {
        super(itemView);
        textName = itemView.findViewById(R.id.text_location_name);
        bookmarkBtn = itemView.findViewById(R.id.button_bookmark);
        deleteBtn = itemView.findViewById(R.id.button_delete);
    }
}

