package com.gproject.safetydirections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.gproject.safetydirections.databinding.ActivityDirectionInputBinding;

public class DirectionInputActivity extends AppCompatActivity {

    private com.gproject.safetydirections.databinding.ActivityDirectionInputBinding binding;
    //    boolean mode = true; //false는 최근 검색, true는 즐겨찾기
    int btnMode = 0; //0은 최근 검색, 1은 즐겨찾기, 2는 지도에서 지정
    MyPoint curPoint;
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDirectionInputBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);//기본 타이틀 제거
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);  //뒤로가기 버튼 생성

        Intent receiveIntent = getIntent();
        curPoint = (MyPoint) receiveIntent.getSerializableExtra("curPoint");

        modeChange();*/

        FragmentView(1);

        binding.editEndButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //검색창으로 이동
                Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                intent.putExtra("num", 10);
                intent.putExtra("curPoint", curPoint);
                startActivity(intent);
            }
        });

        binding.resentSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btnMode == 1) {
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 0;
                } else if (btnMode == 2) {
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 0;
                }

                FragmentView(1);
            }
        });

        binding.bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnMode == 0) {
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 1;
                } else if (btnMode == 2) {
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 1;
                }

                FragmentView(2);
            }
        });

        binding.currentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DirectionReady.class);
                intent.putExtra("num", 10);
                intent.putExtra("curPoint", curPoint);
                intent.putExtra("selectPoint", curPoint);
                startActivity(intent);
            }
        });

        binding.mapSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnMode == 0) {
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 2;
                } else if (btnMode == 1) {
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 2;
                }

                FragmentView(3);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
//        modeChange();
    }

    public boolean onOptionsItemSelected(MenuItem item) { //툴바 뒤로가기
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void FragmentView(int fragment){

        //FragmentTransactiom를 이용해 프래그먼트를 사용합니다.
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        switch (fragment){
            case 1:
                // 첫번 째 프래그먼트 호출
                RSListFragment rsFragment = new RSListFragment(10);
                transaction.replace(R.id.fragment_container, rsFragment);
                transaction.commit();
                break;

            case 2:
                // 두번 째 프래그먼트 호출
                BMListFragment bmFragment = new BMListFragment(10);
                transaction.replace(R.id.fragment_container, bmFragment);
                transaction.commit();
                break;

            case 3:
                // 두번 째 프래그먼트 호출
                MapSearchFragment mapFragment = new MapSearchFragment(10, curPoint);
                transaction.replace(R.id.fragment_container, mapFragment);
                transaction.commit();
                break;
        }
    }

    public void sendPointwithNum(MyPoint point) {
        Intent intent = new Intent(getApplicationContext(), DirectionReady.class);
        intent.putExtra("num", 10);
        intent.putExtra("curPoint", curPoint);
        intent.putExtra("selectPoint", point);
        startActivity(intent);
    }
}