package com.gproject.safetydirections;

import com.skt.Tmap.TMapPoint;

public class MyPointForDB {
//    private static final long serialVersionUID = 1L;
    int id = 0;
    private String name = "";
    private double latitude = 0.0;
    private double longitude = 0.0;
    int isBM = 0;

    MyPointForDB(){

    }

    MyPointForDB(int id, String location_name, double latitude, double longitude, int isBM) {
        this.id = id;
        this.name = location_name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.isBM = isBM;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setIsBM(int isBM) {
        this.isBM = isBM;
    }

    public int getIsBM() {
        return isBM;
    }

    public MyPoint getMyPoint() {
        MyPoint myPoint = new MyPoint(this.name, this.latitude, this.longitude);
        return myPoint;
    }
}
