package com.gproject.safetydirections;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.gproject.safetydirections.databinding.ActivityDirectionReadyBinding;
import com.opencsv.CSVReader;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPOIItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapPolyLine;
import com.skt.Tmap.TMapView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class DirectionReady extends AppCompatActivity {

    private ActivityDirectionReadyBinding binding;
    private TMapView tMapView;
    MyPoint curPoint, startPoint, endPoint;
    int intentNum = 0;
    public Bitmap bitmapMarkerBlue, bitmapMarkerOrange;
    ArrayList<TMapPoint> passList = new ArrayList<TMapPoint>();
    ArrayList<String> routeText = new ArrayList<String>();
    ArrayList<MyPoint> routePoint = new ArrayList<MyPoint>();
    ArrayList<MyPoint> alTMapPoint = new ArrayList<MyPoint>();
    ArrayList<Cctv> selectedCctvs = new ArrayList<Cctv>();
    ArrayList<Cctv> cctvs = new ArrayList<Cctv>();
    final String appKey = ""; //키값 입력
    private boolean run;
    private HistoryDBHelper historyDBHelper;
    SQLiteDatabase historyDatabase;
    private RouteHistoryDBHelper routeHistoryDBHelper;
    SQLiteDatabase rhDatabase;
    private CCTVHistoryDBHelper cctvHistoryDBHelper;
    SQLiteDatabase cctvhDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDirectionReadyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        tMapView = new TMapView(this);

        tMapView.setSKTMapApiKey(appKey);
        binding.linearLayoutTmap.addView(tMapView);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //처음 세팅
        tMapView.setZoomLevel(15);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);

        Intent receiveIntent = getIntent();
        intentNum = receiveIntent.getExtras().getInt("num");
        curPoint = (MyPoint) receiveIntent.getSerializableExtra("curPoint");
        Log.d("길찾기 받은 번호", "" + intentNum);

        tMapView.setLocationPoint(curPoint.getLongitude(), curPoint.getLatitude());
        tMapView.setCenterPoint(curPoint.getLongitude(), curPoint.getLatitude());

        historyDBHelper = new HistoryDBHelper(this);
        routeHistoryDBHelper = new RouteHistoryDBHelper(this);
        cctvHistoryDBHelper = new CCTVHistoryDBHelper(this);
        historyDatabase = historyDBHelper.getWritableDatabase();
        rhDatabase = routeHistoryDBHelper.getWritableDatabase();
        cctvhDatabase = cctvHistoryDBHelper.getWritableDatabase();

        if (intentNum == 10) {
            MyPoint receivePoint = (MyPoint) receiveIntent.getSerializableExtra("selectPoint");
            binding.pointEnd.setText(receivePoint.getName());
            endPoint = new MyPoint(receivePoint.getName(), receivePoint.getLatitude(), receivePoint.getLongitude());
            binding.pointStart.setText("현재위치");
            startPoint = new MyPoint("현재위치", curPoint.getLatitude(), curPoint.getLongitude());
        }
        run = true;

        new Thread() {
            @Override
            public void run() {
                while (run) {
                    drawPath(startPoint, endPoint, null);
                    mark(getCsvData());
                }
            }
        }.start();

        binding.pointStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DirectionChooseActivity.class);
                intent.putExtra("curPoint", curPoint);
                startActivityForResult(intent, 20);
            }
        });

        binding.pointEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DirectionChooseActivity.class);
                intent.putExtra("curPoint", curPoint);
                startActivityForResult(intent, 30);
            }
        });

        binding.exchangeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tmpName = startPoint.getName();
                double tmpLat = startPoint.getLatitude();
                double tmpLong = startPoint.getLongitude();

                startPoint.setName(endPoint.getName());
                startPoint.setLatitude(endPoint.getLatitude());
                startPoint.setLongitude(endPoint.getLongitude());
                binding.pointStart.setText(endPoint.getName());

                endPoint.setName(tmpName);
                endPoint.setLatitude(tmpLat);
                endPoint.setLongitude(tmpLong);
                binding.pointEnd.setText(tmpName);
                Collections.reverse(passList);

                run = true;
                new Thread() {
                    @Override
                    public void run() {
                        while (run) {
                            drawPath(startPoint, endPoint, passList);
                        }
                    }
                }.start();
            }
        });

        binding.closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.chooseCCTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.removeAllTMapPolygon();
                run = true;
                new Thread() {
                    @Override
                    public void run() {
                        while (run) {
                            drawPath(startPoint, endPoint, passList);
                        }
                    }
                }.start();
            }
        });

        binding.startDirections.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                LocalDateTime now = LocalDateTime.now();
                String date = now.getYear() + "-" + now.getMonthValue() + "-" + now.getDayOfMonth();
                String time = now.getHour() + ":" + now.getMinute();
                String departure = startPoint.getName();
                String destination = endPoint.getName();

                String sql = "INSERT INTO historyTBL(date, time, departure, destination) VALUES(?, ?, ?, ?)";
                Object[] params = {date, time, departure, destination};
                historyDatabase.execSQL(sql, params);

                int id = 0;
                String selectSql = "SELECT _id FROM historyTBL  where date='" + date + "' AND time='" + time + "' AND departure='" + departure + "' AND destination='" + destination + "';";
                Cursor cursor = historyDatabase.rawQuery(selectSql, null);
                while (cursor.moveToNext()) {
                    id = cursor.getInt(0);
                }
                cursor.close();

                for (int i = 0; i < alTMapPoint.size(); i++) {
                    String rhSql = "INSERT INTO routeHistoryTBL(_id, listNum, latitude, longitude) VALUES(?, ?, ?, ?)";
                    Object[] rhParams = {id, i, alTMapPoint.get(i).getLatitude(), alTMapPoint.get(i).getLongitude()};
                    rhDatabase.execSQL(rhSql, rhParams);
                }

                for (int i = 0; i < selectedCctvs.size(); i++) {
                    String chSql = "INSERT INTO cctvHistoryTBL(_id, listNum, institution, count, direction, latitude, longitude) VALUES(?, ?, ?, ?, ?, ?, ?)";
                    Object[] chParams = {id, i, selectedCctvs.get(i).getInstitution(), selectedCctvs.get(i).getCount(), selectedCctvs.get(i).getDirection(),
                            selectedCctvs.get(i).getLatitude(), selectedCctvs.get(i).getLongitude()};
                    cctvhDatabase.execSQL(chSql, chParams);
                }

                Intent intent = new Intent(getApplicationContext(), NavigationActivity.class);
//                intent.putExtra("startPoint", startPoint);
//                intent.putExtra("endPoint", endPoint);
                intent.putExtra("alTMapPoint", alTMapPoint);
                intent.putStringArrayListExtra("routeText", routeText);
                intent.putExtra("routePoint", routePoint);
                intent.putExtra("selectedCctvs", selectedCctvs);
                startActivity(intent);
                run = false;
            }
        });

        tMapView.setOnClickListenerCallBack(new TMapView.OnClickListenerCallback() {
            @Override
            public boolean onPressUpEvent(ArrayList<TMapMarkerItem> arrayList, ArrayList<TMapPOIItem> arrayList1, TMapPoint tMapPoint, PointF pointF) {
                return false;
            }

            @Override
            public boolean onPressEvent(ArrayList<TMapMarkerItem> markerlist, ArrayList<TMapPOIItem> poilist, TMapPoint point, PointF pointf) {
                if (!markerlist.isEmpty()) {
                    for (int i = 0; i < markerlist.size(); i++) {
                        TMapMarkerItem item = markerlist.get(i);
                        int id = Integer.parseInt(item.getID());
                        Cctv myCctvItem = new Cctv(cctvs.get(id).getInstitution(), cctvs.get(id).getCount(), cctvs.get(id).getDirection(),
                                cctvs.get(id).getLatitude(), cctvs.get(id).getLongitude());
                        //MyPoint myPointItem = new MyPoint(Integer.toString(i), item.getTMapPoint());

                        if (item.getIcon() == bitmapMarkerBlue) {
                            item.setIcon(bitmapMarkerOrange);
                            passList.add(item.getTMapPoint());
                            selectedCctvs.add(myCctvItem);
                        } else if (item.getIcon() == bitmapMarkerOrange) {
                            item.setIcon(bitmapMarkerBlue);
                            passList.remove(item.getTMapPoint());
                            selectedCctvs.remove(myCctvItem);
                        }
                    }
                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 20) {
            if (resultCode == RESULT_OK) {
                MyPoint receiveStartPoint = (MyPoint) data.getSerializableExtra("selectPoint");

                binding.pointStart.setText(receiveStartPoint.getName());
                startPoint.setName(receiveStartPoint.getName());
                startPoint.setLatitude(receiveStartPoint.getLatitude());
                startPoint.setLongitude(receiveStartPoint.getLongitude());

                run = true;
                new Thread() {
                    @Override
                    public void run() {
                        while (run) {
                            drawPath(startPoint, endPoint, null);
                        }
                    }
                }.start();
            } else {
                Toast.makeText(this, "오류가 발생했습니다!", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == 30) {
            if (resultCode == RESULT_OK) {
                MyPoint receiveEndPoint = (MyPoint) data.getSerializableExtra("selectPoint");

                binding.pointEnd.setText(receiveEndPoint.getName());
                endPoint.setName(receiveEndPoint.getName());
                endPoint.setLatitude(receiveEndPoint.getLatitude());
                endPoint.setLongitude(receiveEndPoint.getLongitude());

                run = true;
                new Thread() {
                    @Override
                    public void run() {
                        while (run) {
                            drawPath(startPoint, endPoint, null);
                        }
                    }
                }.start();
            } else {
                Toast.makeText(this, "!!!!오류가 발생했습니다!!!!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void drawPath(MyPoint startPoint, MyPoint endPoint, ArrayList<TMapPoint> passList) {
        StringBuffer sb = new StringBuffer();
        String type = "";
        String discription = "";
        sb.append("startX=" + Double.toString(startPoint.getLongitude()) + "&startY=" + Double.toString(startPoint.getLatitude())
                + "&endX=" + Double.toString(endPoint.getLongitude()) + "&endY=" + Double.toString(endPoint.getLatitude())
                + "&startName=" + startPoint.getName() + "&endName=" + endPoint.getName());
        if (passList != null) {
            if (passList.size() > 0) {
                int listSize = passList.size();
                sb.append("&passList=");
                for (int i = 0; i < listSize - 1; i++) {
                    sb.append(Double.toString(passList.get(i).getLongitude()) + "," + Double.toString(passList.get(i).getLatitude()) + "_");
                }
                sb.append(Double.toString(passList.get(listSize - 1).getLongitude()) + "," + Double.toString(passList.get(listSize - 1).getLatitude()));
            }
        }

        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder(); //XML문서 빌더 객체를 생성
            Document doc;

            URL url = new URL("https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn != null) {
                conn.setConnectTimeout(10000); // 10초 동안 기다린 후 응답이 없으면 종료
                conn.setRequestMethod("POST");
                conn.setRequestProperty("appKey", appKey);
                conn.setRequestProperty("Accept", "application/xml");
                conn.setDoInput(true);
                conn.setDoOutput(true);
                // Request Body에 Data를 담기
                OutputStream os = conn.getOutputStream();
                String body = sb.toString();
                os.write(body.getBytes("UTF-8"));
                os.flush();
                os.close();

                int resCode = conn.getResponseCode();
                if (resCode == HttpURLConnection.HTTP_OK) {
                    TMapPolyLine tMapPolyLine = new TMapPolyLine();
                    tMapPolyLine.setLineColor(ContextCompat.getColor(getBaseContext(), R.color.pathColor));
                    tMapPolyLine.setLineWidth(15);
                    alTMapPoint.clear();
                    routePoint.clear();
                    routeText.clear();
                    doc = db.parse(new InputSource(conn.getInputStream())); //XML문서를 파싱한다.

                    NodeList Dis = doc.getElementsByTagName("tmap:totalDistance");
                    int distance = Integer.parseInt(Dis.item(0).getChildNodes().item(0).getNodeValue());
                    if (distance < 1000) {
                        binding.resultDistance.setText(distance + "m");
                    } else {
                        double d = Math.round(distance / 10.0) / 100.0;
                        binding.resultDistance.setText(d + "km");
                    }

                    NodeList time = doc.getElementsByTagName("tmap:totalTime");
                    int timeS = Integer.parseInt(time.item(0).getChildNodes().item(0).getNodeValue());
                    if (timeS > 3600) {
                        int timeM = timeS / 60;
                        binding.resultTime.setText(timeM / 60 + "시간" + timeM % 60 + "분");
                    } else {
                        binding.resultTime.setText(timeS / 60 + "분");
                    }

                    NodeList nodeListPlacemark = doc.getElementsByTagName("Placemark");
                    for (int i = 0; i < nodeListPlacemark.getLength(); i++) {
                        NodeList nodeListPlacemarkItem = nodeListPlacemark.item(i).getChildNodes();
                        for (int j = 0; j < nodeListPlacemarkItem.getLength(); j++) {
                            if (nodeListPlacemarkItem.item(j).getNodeName().equals("description")) {
                                discription = nodeListPlacemarkItem.item(j).getTextContent().trim();
                            } else if (nodeListPlacemarkItem.item(j).getNodeName().equals("LineString")) {
                                Element item = (Element) nodeListPlacemarkItem.item(j);
                                NodeList point = item.getElementsByTagName("coordinates");
                                String location[] = point.item(0).getChildNodes().item(0).getNodeValue().split(" ");
                                for (int k = 0; k < location.length; k++) {
                                    try {
                                        String[] locationPoint = location[k].split(",");
                                        alTMapPoint.add(new MyPoint("", Double.parseDouble(locationPoint[1]), Double.parseDouble(locationPoint[0])));
                                    } catch (Exception e) {
                                    }
                                }
                            } else if (nodeListPlacemarkItem.item(j).getNodeName().equals("Point")) {
                                Element item = (Element) nodeListPlacemarkItem.item(j);
                                NodeList point = item.getElementsByTagName("coordinates");
                                String location[] = point.item(0).getChildNodes().item(0).getNodeValue().split(",");
                                routePoint.add(new MyPoint("", Double.parseDouble(location[1]), Double.parseDouble(location[0])));
                                Log.d("테스트 (포인트)", location[1] + "," + location[0] + ".");
                            } else if (nodeListPlacemarkItem.item(j).getNodeName().equals("tmap:nodeType")) {
                                type = nodeListPlacemarkItem.item(j).getTextContent();
                            }
                        }
                        if (type.equals("POINT")) {
                            routeText.add(discription + "하세요.");
                            Log.d("테스트", discription);
                        }
                    }

                    routeText.set(routeText.size() - 1, "도착입니다.");

                    Log.d("테스트", routeText.get(routeText.size() - 1));

                    for (int i = 0; i < alTMapPoint.size(); i++) {
                        tMapPolyLine.addLinePoint(alTMapPoint.get(i).getTMapPoint());
                    }
                    tMapView.addTMapPolyLine("path", tMapPolyLine);
                    Bitmap start = BitmapFactory.decodeResource(getBaseContext().getResources(), R.drawable.start);
                    Bitmap end = BitmapFactory.decodeResource(getBaseContext().getResources(), R.drawable.end);

                    TMapMarkerItem markerStart = new TMapMarkerItem();
                    markerStart.setIcon(start);
                    markerStart.setTMapPoint(alTMapPoint.get(0).getTMapPoint());
                    tMapView.addMarkerItem("markerStart", markerStart);

                    TMapMarkerItem markerEnd = new TMapMarkerItem();
                    markerEnd.setIcon(end);
                    markerEnd.setTMapPoint(alTMapPoint.get(alTMapPoint.size() - 1).getTMapPoint());
                    tMapView.addMarkerItem("markerEnd", markerEnd);
                }
                conn.disconnect();
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
        run = false;
    }

    public void mark(ArrayList<Cctv> cctvs) {
        bitmapMarkerBlue = BitmapFactory.decodeResource(getResources(), R.drawable.marker_blue);
        bitmapMarkerOrange = BitmapFactory.decodeResource(getResources(), R.drawable.marker_red);
        for (int i = 0; i < cctvs.size(); i++) {
            TMapPoint point = new TMapPoint(cctvs.get(i).getLatitude(), cctvs.get(i).getLongitude());
            TMapMarkerItem markerItem = new TMapMarkerItem();

            markerItem.setIcon(bitmapMarkerBlue);
            markerItem.setPosition(0.5f, 1.0f);
            markerItem.setTMapPoint(point);
            tMapView.addMarkerItem("" + i, markerItem);
        }
        run = false;
    }

    public ArrayList<Cctv> getCsvData() {
        cctvs.clear();
        InputStreamReader is = new InputStreamReader(getResources().openRawResource(R.raw.data_cctv));
        BufferedReader reader = new BufferedReader(is);
        CSVReader read = new CSVReader(reader);
        String[] record = null;
        try {
            while ((record = read.readNext()) != null) {
                Cctv cctv = new Cctv(record[0], Integer.valueOf(record[1]), record[2], Double.valueOf(record[3]), Double.valueOf(record[4]));
                cctvs.add(cctv);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.d("csv파일", "읽기 끝");

        return cctvs;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        run = false;
    }

}