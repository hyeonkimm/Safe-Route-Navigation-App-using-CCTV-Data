package com.gproject.safetydirections;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryHolder> {
    Context context;
    ArrayList<HistoryItem> list = new ArrayList<HistoryItem>();

    HistoryAdapter() {
        list = new ArrayList<HistoryItem>();
    }

    HistoryAdapter(ArrayList<HistoryItem> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.item_history, parent, false);
        return new HistoryHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final HistoryHolder holder, int position) {
        final HistoryItem item = list.get(position);
        holder.text_date.setText(item.getDate());
        holder.text_time.setText(item.getTime());
        holder.location_name.setText(item.getDeparture() + " ~ " + item.getDestination());

        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((HistoryActivity) context).clickDeleteBtn(item);
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((HistoryActivity) context).goToDetail(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void clear() {
        list.clear();
        notifyDataSetChanged();
    }

    public void addItem(HistoryItem item) {
        list.add(0, item);
    }

    public void removeItem(HistoryItem item) {
        list.remove(item);
        notifyDataSetChanged();
    }
}

class HistoryHolder extends RecyclerView.ViewHolder {
    public TextView text_date;
    public TextView text_time;
    public TextView location_name;
    public ImageView deleteBtn;

    public HistoryHolder(@NonNull View itemView) {
        super(itemView);
        text_date = itemView.findViewById(R.id.text_date);
        text_time = itemView.findViewById(R.id.text_time);
        location_name = itemView.findViewById(R.id.location_name);
        deleteBtn = itemView.findViewById(R.id.button_delete);
    }
}

