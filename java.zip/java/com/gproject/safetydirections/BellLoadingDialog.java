package com.gproject.safetydirections;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;

public class BellLoadingDialog extends Dialog {
    public BellLoadingDialog(Context context)
    {
        super(context);
        // 다이얼 로그 제목을 안보이게...
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_bell_loading);
        setCancelable(false);
    }
}
