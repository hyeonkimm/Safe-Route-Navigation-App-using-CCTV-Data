package com.gproject.safetydirections;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.gproject.safetydirections.databinding.ActivityHistoryDetailBinding;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPOIItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapPolyLine;
import com.skt.Tmap.TMapView;

import java.util.ArrayList;

public class HistoryDetailActivity extends AppCompatActivity {

    private ActivityHistoryDetailBinding binding;
    private TMapView tMapView;
    final String appKey = ""; //키값 입력
    int itemId = 0;

    private HistoryDBHelper historyDBHelper;
    SQLiteDatabase historyDatabase;
    private RouteHistoryDBHelper routeHistoryDBHelper;
    SQLiteDatabase rhDatabase;
    private CCTVHistoryDBHelper cctvHistoryDBHelper;
    SQLiteDatabase cctvhDatabase;

    ArrayList<MyPoint> alTMapPoint = new ArrayList<MyPoint>();
    ArrayList<Cctv> cctvPoint = new ArrayList<Cctv>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHistoryDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        tMapView = new TMapView(this);

        tMapView.setSKTMapApiKey(appKey);
        binding.linearLayoutTmap.addView(tMapView);

        tMapView.setZoomLevel(15);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);

        Intent receiveIntent = getIntent();
        itemId = receiveIntent.getExtras().getInt("id");

        historyDBHelper = new HistoryDBHelper(this);
        routeHistoryDBHelper = new RouteHistoryDBHelper(this);
        cctvHistoryDBHelper = new CCTVHistoryDBHelper(this);
        historyDatabase = historyDBHelper.getWritableDatabase();
        rhDatabase = routeHistoryDBHelper.getWritableDatabase();
        cctvhDatabase = cctvHistoryDBHelper.getWritableDatabase();

        binding.zoomPlusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomIn();
            }
        });

        binding.zoomMinusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomOut();
            }
        });

        binding.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                historyDatabase.execSQL("delete from historyTBL where _id=" + itemId + ";");
                rhDatabase.execSQL("delete from routeHistoryTBL where _id=" + itemId + ";");
                cctvhDatabase.execSQL("delete from cctvHistoryTBL where _id=" + itemId + ";");
                finish();
            }
        });

        if (rhDatabase != null) {
            String sql = "select * from routeHistoryTBL where _id=" + itemId + " order by listNum asc;";
            Cursor cursor = rhDatabase.rawQuery(sql, null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                int listNum = cursor.getInt(1);
                double latitude = cursor.getDouble(2);
                double longitude = cursor.getDouble(3);

                alTMapPoint.add(new MyPoint("", latitude, longitude));
            }
            cursor.close();
        }

        TMapPoint  startPoint = new TMapPoint (alTMapPoint.get(0).getLatitude(), alTMapPoint.get(0).getLongitude());
        TMapPoint endPoint = new TMapPoint(alTMapPoint.get(alTMapPoint.size() - 1).getLatitude(), alTMapPoint.get(alTMapPoint.size() - 1).getLongitude());

        tMapView.setCenterPoint((startPoint.getLongitude() + endPoint.getLongitude()) / 2,
                (startPoint.getLatitude() + endPoint.getLatitude()) / 2); //지도 중앙을 출발지와 도착지의 위도, 경도 중간으로

        TMapPolyLine tMapPolyLine = new TMapPolyLine();
        tMapPolyLine.setLineColor(ContextCompat.getColor(getBaseContext(), R.color.pathColor));
        tMapPolyLine.setLineWidth(15);

        for (int i = 0; i < alTMapPoint.size(); i++) {
            tMapPolyLine.addLinePoint(alTMapPoint.get(i).getTMapPoint());
        }

        tMapView.addTMapPolyLine("path", tMapPolyLine);
        Bitmap start = BitmapFactory.decodeResource(getBaseContext().getResources(), R.drawable.start);
        Bitmap end = BitmapFactory.decodeResource(getBaseContext().getResources(), R.drawable.end);

        TMapMarkerItem markerStart = new TMapMarkerItem();
        markerStart.setIcon(start);
        markerStart.setTMapPoint(startPoint);
        tMapView.addMarkerItem("markerStart", markerStart);

        TMapMarkerItem markerEnd = new TMapMarkerItem();
        markerEnd.setIcon(end);
        markerEnd.setTMapPoint(endPoint);
        tMapView.addMarkerItem("markerEnd", markerEnd);

        if (cctvhDatabase != null) {
            String sql = "select * from cctvHistoryTBL where _id=" + itemId + " order by listNum asc;";
            Cursor cursor = cctvhDatabase.rawQuery(sql, null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                int listNum = cursor.getInt(1);
                String institution = cursor.getString(2);
                int count = cursor.getInt(3);
                String direction = cursor.getString(4);
                double latitude = cursor.getDouble(5);
                double longitude = cursor.getDouble(6);

                cctvPoint.add(new Cctv(institution, count, direction, latitude, longitude));
            }
            cursor.close();
        }

        Bitmap bitmapMarkerOrange;
        bitmapMarkerOrange = BitmapFactory.decodeResource(getResources(), R.drawable.marker_red);
        for (int i = 0; i < cctvPoint.size(); i++) {
            TMapPoint point = new TMapPoint(cctvPoint.get(i).getLatitude(), cctvPoint.get(i).getLongitude());
            TMapMarkerItem markerItem = new TMapMarkerItem();

            markerItem.setIcon(bitmapMarkerOrange);
            markerItem.setPosition(0.5f, 1.0f);
            markerItem.setTMapPoint(point);
            tMapView.addMarkerItem("" + i, markerItem);
        }

        tMapView.setOnClickListenerCallBack(new TMapView.OnClickListenerCallback() {
            @Override
            public boolean onPressUpEvent(ArrayList<TMapMarkerItem> arrayList, ArrayList<TMapPOIItem> arrayList1, TMapPoint tMapPoint, PointF pointF) {
                return false;
            }

            @Override
            public boolean onPressEvent(ArrayList<TMapMarkerItem> markerlist, ArrayList<TMapPOIItem> poilist, TMapPoint point, PointF pointf) {
                if (!markerlist.isEmpty()) {
                    for (int i = 0; i < markerlist.size(); i++) {
                        TMapMarkerItem item = markerlist.get(i);
                        int id = Integer.parseInt(item.getID());
                        AlertDialog.Builder helpBuilder = new AlertDialog.Builder(HistoryDetailActivity.this)
                                .setTitle("CCTV 상세 정보")
                                .setMessage("관리기관 : " + cctvPoint.get(id).getInstitution() + "\n"
                                        + "카메라대수 : " + cctvPoint.get(id).getCount() + "\n"
                                        + "촬영방면 : " + cctvPoint.get(id).getDirection())
                                .setPositiveButton("확인", null);
                        helpBuilder.show();
                    }
                }
                return false;
            }
        });
    }
}