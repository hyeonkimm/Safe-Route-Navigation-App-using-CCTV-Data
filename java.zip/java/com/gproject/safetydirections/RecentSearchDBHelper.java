package com.gproject.safetydirections;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Locale;

public class RecentSearchDBHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "recentSearch.db";
    public static final String TABLE_NAME = "recentSearchTBL";

    public RecentSearchDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "("
                + "_id integer primary key autoincrement,"
                + "name text,"
                + "latitude double,"
                + "longitude double,"
                + "isBM integer);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    void isDuplicated(String name, double latitude, double longitude) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT _id FROM " + TABLE_NAME + " WHERE name='"+name+"' AND latitude="+latitude+" AND longitude="+ longitude +";", null);
        if (cursor.moveToFirst()) {
            Log.d("데이터베이스", "중복 데이터를 삭제 후 삽입합니다.");
            db.execSQL("delete from " + TABLE_NAME + " WHERE name='"+name+"' AND latitude="+latitude+" AND longitude="+ longitude +";");
        }
        cursor.close();
    }
}
