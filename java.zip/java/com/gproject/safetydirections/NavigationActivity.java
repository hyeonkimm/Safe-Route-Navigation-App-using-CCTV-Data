package com.gproject.safetydirections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;

import com.gproject.safetydirections.databinding.ActivityNavigationBinding;
import com.skt.Tmap.TMapGpsManager;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapPolyLine;
import com.skt.Tmap.TMapView;

import java.util.ArrayList;
import java.util.Locale;


public class NavigationActivity extends AppCompatActivity implements TextToSpeech.OnInitListener, TMapGpsManager.onLocationChangedCallback {
    private ActivityNavigationBinding binding;

    private TMapView tMapView;
    private TMapGpsManager tMapGPS;
    ArrayList<String> routeText = new ArrayList<String>();
    ArrayList<MyPoint> alTMapPoint = new ArrayList<MyPoint>();
    ArrayList<MyPoint> routePoint = new ArrayList<MyPoint>();
    ArrayList<Cctv> selectedCctvs = new ArrayList<Cctv>();
    private TextToSpeech tts;
    double curLongitude;
    double curLatitude;
    TMapPolyLine pastPolyline;
    public Bitmap bitmapMarkerBlue, bitmapMarkerOrange;
    SharedPreferences pref;
    boolean speak = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNavigationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        tMapView = new TMapView(this);
        TMapPolyLine tMapPolyLine = new TMapPolyLine();
        tMapPolyLine.setLineColor(ContextCompat.getColor(getBaseContext(), R.color.pathColor));
        tMapPolyLine.setLineWidth(17);
        pastPolyline = new TMapPolyLine();
        pastPolyline.setLineColor(ContextCompat.getColor(getBaseContext(), R.color.pastPathColor));
        pastPolyline.setLineWidth(17);

        tMapView.setSKTMapApiKey(""); //키값 입력
        binding.linearLayoutTmap.addView(tMapView);

        //처음 세팅
        tMapView.setZoomLevel(18);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);
        tMapView.setTrackingMode(true);
        tMapView.setIconVisibility(true);
        Bitmap iconBitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.navigation_64_65);
        tMapView.setIcon(iconBitmap);
        tMapView.setCompassMode(true);
        tMapView.setSightVisible(true);

        Intent receiveIntent = getIntent();
        routeText = receiveIntent.getStringArrayListExtra("routeText");
        alTMapPoint = (ArrayList<MyPoint>) receiveIntent.getSerializableExtra("alTMapPoint");
        routePoint = (ArrayList<MyPoint>) receiveIntent.getSerializableExtra("routePoint");
        selectedCctvs = (ArrayList<Cctv>) receiveIntent.getSerializableExtra("selectedCctvs");

        tMapGPS = new TMapGpsManager(this);
        tMapGPS.setMinTime(1000);
        tMapGPS.setMinDistance(5);
        tMapGPS.setProvider(TMapGpsManager.GPS_PROVIDER);
        tMapGPS.OpenGps();

        pref = PreferenceManager.getDefaultSharedPreferences(this);
        speak = pref.getBoolean("speak", true);
        if(speak){
            tts = new TextToSpeech(this, this);
        }
        tts = new TextToSpeech(this, this);



        binding.currentLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                curLongitude = tMapGPS.getLocation().getLongitude();
                curLatitude = tMapGPS.getLocation().getLatitude();
                tMapView.setLocationPoint(curLongitude, curLatitude);
                tMapView.setCenterPoint(curLongitude, curLatitude);
            }
        });

        binding.zoomPlusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomIn();
            }
        });

        binding.zoomMinusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomOut();
            }
        });

        for (int i = 0; i < alTMapPoint.size(); i++) {
            tMapPolyLine.addLinePoint(alTMapPoint.get(i).getTMapPoint());
        }
        tMapView.addTMapPolyLine("path", tMapPolyLine);

        Bitmap end = BitmapFactory.decodeResource(getBaseContext().getResources(), R.drawable.end);
        TMapMarkerItem markerEnd = new TMapMarkerItem();
        markerEnd.setIcon(end);
        markerEnd.setTMapPoint(alTMapPoint.get(alTMapPoint.size()-1).getTMapPoint());
        tMapView.addMarkerItem("markerEnd", markerEnd);
        mark(selectedCctvs);
    }

    public double getDistance(double lat1 , double lng1 , double lat2 , double lng2 ){
        double distance;

        Location locationA = new Location("point A");
        locationA.setLatitude(lat1);
        locationA.setLongitude(lng1);

        Location locationB = new Location("point B");
        locationB.setLatitude(lat2);
        locationB.setLongitude(lng2);

        distance = locationA.distanceTo(locationB);

        return distance;
    }

    @Override
    public void onLocationChange(Location location) {
        curLatitude = location.getLatitude();
        curLongitude = location.getLongitude();
        tMapView.setLocationPoint(location.getLongitude(), location.getLatitude());
        tMapView.setCenterPoint(location.getLongitude(), location.getLatitude());
        if(speak) {
            if (10.0 > getDistance(curLatitude, curLongitude, routePoint.get(0).getLatitude(), routePoint.get(0).getLongitude())) {
                tts.speak(routeText.get(0), TextToSpeech.QUEUE_FLUSH, null, "id");
                binding.directionText.setText(routeText.get(0));

                routePoint.remove(0);
                routeText.remove(0);
            }
        } else {
            if (10.0 > getDistance(curLatitude, curLongitude, routePoint.get(0).getLatitude(), routePoint.get(0).getLongitude())) {
                binding.directionText.setText(routeText.get(0));

                routePoint.remove(0);
                routeText.remove(0);
            }
        }

        TMapPoint pastPoint = new TMapPoint(curLatitude,curLongitude);
        pastPolyline.addLinePoint(pastPoint);
        tMapView.addTMapPolyLine("pastPath", pastPolyline);
    }

    @Override
    protected void onDestroy() {
        // TTS 객체가 남아있다면 실행을 중지하고 메모리에서 제거한다.
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.KOREA);

            pref = PreferenceManager.getDefaultSharedPreferences(this);

            tts.setSpeechRate(Float.parseFloat(pref.getString("speed", "1.0"))); // 읽는 속도
            tts.setPitch(Float.parseFloat(pref.getString("pitch", "1.0"))); // 음성 톤

            Log.d("나오나", pref.getString("speed", "1.0") + ", " + pref.getString("pitch", "1.0"));
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "This Language is not supported");
            } else {

            }
        } else {
            Log.e("TTS", "초기화 실패");
        }
    }

    public void mark(ArrayList<Cctv> selectedCctvs) {
        bitmapMarkerBlue = BitmapFactory.decodeResource(getResources(), R.drawable.marker_blue);
        bitmapMarkerOrange = BitmapFactory.decodeResource(getResources(), R.drawable.marker_red);
        for (int i = 0; i < selectedCctvs.size(); i++) {
            TMapPoint point = new TMapPoint(selectedCctvs.get(i).getLatitude(), selectedCctvs.get(i).getLongitude());
            TMapMarkerItem markerItem = new TMapMarkerItem();

            markerItem.setIcon(bitmapMarkerOrange);
            markerItem.setPosition(0.5f, 1.0f);
            markerItem.setTMapPoint(point);
            tMapView.addMarkerItem("markerItem" + i, markerItem);
        }
    }
}