package com.gproject.safetydirections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.gproject.safetydirections.databinding.ActivityDirectionChooseBinding;

public class DirectionChooseActivity extends AppCompatActivity {

    private ActivityDirectionChooseBinding binding;
//    boolean mode = true; //false는 최근 검색, true는 즐겨찾기
    int btnMode = 0; //0은 최근 검색, 1은 즐겨찾기, 2는 지도에서 지정
    MyPoint curPoint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDirectionChooseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Intent receiveIntent = getIntent();
        curPoint = (MyPoint) receiveIntent.getSerializableExtra("curPoint");

        FragmentView(1);

        binding.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                intent.putExtra("curPoint", curPoint);
                startActivity(intent);
                finish();
            }
        });

        binding.resentSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnMode == 1) {
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 0;
                } else if (btnMode == 2) {
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 0;
                }

                FragmentView(1);
            }
        });

        binding.bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnMode == 0) {
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 1;
                } else if (btnMode == 2) {
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 1;
                }

                FragmentView(2);
            }
        });

        binding.currentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("curPoint", curPoint);
                intent.putExtra("selectPoint", curPoint);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        binding.mapSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnMode == 0) {
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.resentSearch.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 2;
                } else if (btnMode == 1) {
                    binding.mapSearch.setBackground(getDrawable(R.drawable.button_round_pressed));
                    binding.bookmark.setBackground(getDrawable(R.drawable.button_round_lightgray));
                    btnMode = 2;
                }

                FragmentView(3);
            }
        });
    }

    private void FragmentView(int fragment){

        //FragmentTransactiom를 이용해 프래그먼트를 사용합니다.
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        switch (fragment){
            case 1:
                // 첫번 째 프래그먼트 호출
                RSListFragment rsFragment = new RSListFragment();
                transaction.replace(R.id.fragment_container, rsFragment);
                transaction.commit();
                break;

            case 2:
                // 두번 째 프래그먼트 호출
                BMListFragment bmFragment = new BMListFragment();
                transaction.replace(R.id.fragment_container, bmFragment);
                transaction.commit();
                break;

            case 3:
                // 두번 째 프래그먼트 호출
                MapSearchFragment mapFragment = new MapSearchFragment(curPoint);
                transaction.replace(R.id.fragment_container, mapFragment);
                transaction.commit();
                break;
        }
    }

    public void sendPoint(MyPoint point){
        Intent intent = new Intent();
        intent.putExtra("curPoint", curPoint);
        intent.putExtra("selectPoint", point);
        setResult(RESULT_OK, intent);
        finish();
    }
}