package com.gproject.safetydirections;

public class Bell {
    private String locationType; //설치장소 유형
    private String lacoation;    //설치위치
    private String adress;       //소재지도로명주소
    private double latitude;     //위도
    private double longitude;    //경도

    public Bell() {

    }

    public  Bell(String locationType, String lacoation, String adress, double latitude, double longitude) {
        this.locationType = locationType;
        this.lacoation = lacoation;
        this.adress = adress;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getLocationType() {
        return locationType;
    }

    public String getLocation() {
        return lacoation;
    }

    public String getAdress() {
        return adress;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public  void setLocationType(String locationType){
        this.locationType = locationType;
    }

    public  void setLocation(String lacoation){
        this.lacoation = lacoation;
    }

    public  void setAdress(String adress){
        this.adress = adress;
    }

    public  void setLatitude(double latitude){
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
