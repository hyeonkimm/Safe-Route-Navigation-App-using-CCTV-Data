package com.gproject.safetydirections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import com.gproject.safetydirections.databinding.ActivityHistoryBinding;

public class HistoryActivity extends AppCompatActivity {
    private com.gproject.safetydirections.databinding.ActivityHistoryBinding binding;
    HistoryAdapter historyAdapter;

    private HistoryDBHelper historyDBHelper;
    SQLiteDatabase historyDatabase;
    private RouteHistoryDBHelper routeHistoryDBHelper;
    SQLiteDatabase rhDatabase;
    private CCTVHistoryDBHelper cctvHistoryDBHelper;
    SQLiteDatabase cctvhDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        historyDBHelper = new HistoryDBHelper(this);
        routeHistoryDBHelper = new RouteHistoryDBHelper(this);
        cctvHistoryDBHelper = new CCTVHistoryDBHelper(this);
        historyDatabase = historyDBHelper.getWritableDatabase();
        rhDatabase = routeHistoryDBHelper.getWritableDatabase();
        cctvhDatabase = cctvHistoryDBHelper.getWritableDatabase();

        binding.recyclerview.setLayoutManager(new LinearLayoutManager(this));
        historyAdapter = new HistoryAdapter();
        binding.recyclerview.setAdapter(historyAdapter);
        showList();

        binding.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        binding.deleteAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                historyDatabase.execSQL("delete from historyTBL;");
                rhDatabase.execSQL("delete from routeHistoryTBL;");
                cctvhDatabase.execSQL("delete from cctvHistoryTBL;");

                historyAdapter.clear();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        showList();
    }

    public void showList() {
        historyAdapter.clear();

        if (historyDatabase != null) {
            String sql = "SELECT * FROM historyTBL;";
            Cursor cursor = historyDatabase.rawQuery(sql, null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                String time = cursor.getString(2);
                String departure = cursor.getString(3);
                String destination = cursor.getString(4);

                HistoryItem item = new HistoryItem(id, date, time, departure, destination);
                historyAdapter.addItem(item);
            }
            cursor.close();
        }
    }

    public void goToDetail(HistoryItem item) {
        Intent intent = new Intent(getApplicationContext(), HistoryDetailActivity.class);
        intent.putExtra("id", item.getId());
        startActivity(intent);
    }

    public void clickDeleteBtn(HistoryItem item) {
        historyDatabase.execSQL("delete from historyTBL where _id=" + item.getId() + ";");
        rhDatabase.execSQL("delete from routeHistoryTBL where _id=" + item.getId() + ";");
        cctvhDatabase.execSQL("delete from cctvHistoryTBL where _id=" + item.getId() + ";");
        historyAdapter.removeItem(item);
    }
}