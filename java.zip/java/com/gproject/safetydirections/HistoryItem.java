package com.gproject.safetydirections;

public class HistoryItem {
//    private static final long serialVersionUID = 1L;
    private int id = 0;
    private String date;
    private String time;
    private String departure;
    private String destination;

    HistoryItem(){

    }

    HistoryItem(int id, String date, String time, String departure, String destination) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.departure = departure;
        this.destination = destination;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDestination() {
        return destination;
    }
}
