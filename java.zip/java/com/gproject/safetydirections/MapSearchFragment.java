package com.gproject.safetydirections;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.skt.Tmap.TMapView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapSearchFragment extends Fragment {

    private TMapView tMapView;
    String gpsToAddress;
    int intentNum = 0;
    MyPoint curPoint;

    public MapSearchFragment(MyPoint curPoint) {
        this.curPoint = curPoint;
    }

    public MapSearchFragment(int intentNum, MyPoint curPoint) {
        this.intentNum = intentNum;
        this.curPoint = curPoint;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_map_search, container, false);
        LinearLayout selectTmap = rootView.findViewById(R.id.selectTmap);
        ImageView currentLocationBtn = rootView.findViewById(R.id.currentLocationBtn);
        ImageView zoomPlusBtn = rootView.findViewById(R.id.zoomPlusBtn);
        ImageView zoomMinusBtn = rootView.findViewById(R.id.zoomMinusBtn);

        tMapView = new TMapView(getContext());
        tMapView.setSKTMapApiKey("l7xx429f763f4bd64cdeaa876f8e0c28d228");
        TextView selcetText = rootView.findViewById(R.id.selcetText);

        selectTmap.addView(tMapView);
        tMapView.setZoomLevel(15);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);
        tMapView.setIconVisibility(true);

        tMapView.setLocationPoint(curPoint.getLongitude(), curPoint.getLatitude());
        tMapView.setCenterPoint(curPoint.getLongitude(), curPoint.getLatitude());

        currentLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.setLocationPoint(curPoint.getLongitude(), curPoint.getLatitude());
                tMapView.setCenterPoint(curPoint.getLongitude(), curPoint.getLatitude());
            }
        });

        zoomPlusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomIn();
            }
        });

        zoomMinusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tMapView.MapZoomOut();
            }
        });

        selcetText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double selectLatitude = tMapView.getCenterPoint().getLatitude();
                double selectLongitude = tMapView.getCenterPoint().getLongitude();

                Geocoder geocoder = new Geocoder(getContext(), Locale.KOREA);
                List<Address> address = null;

                try {
                    if (geocoder != null) {
                        // 한좌표에 대해 두개이상의 이름이 존재할수있기에 주소배열을 리턴받음. 주소의 최대 갯수를 1로 1개만 받음.
                        address = geocoder.getFromLocation(selectLatitude, selectLongitude, 1);

                        if (address != null && address.size() > 0) {
                            // 주소 받아오기
                            gpsToAddress = address.get(0).getAddressLine(0).toString();
                            gpsToAddress = gpsToAddress.replace("대한민국 ", "");
                        }
                    }
                } catch (IOException e) {
                    Toast.makeText(getContext(), "주소를 가져 올 수 없습니다.", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

                if (intentNum == 10) {
                    MyPoint selectPoint = new MyPoint(gpsToAddress, selectLatitude, selectLongitude);
                    ((DirectionInputActivity) getActivity()).sendPointwithNum(selectPoint);
                } else {
                    MyPoint selectPoint = new MyPoint(gpsToAddress, selectLatitude, selectLongitude);
                    ((DirectionChooseActivity) getActivity()).sendPoint(selectPoint);
                }
            }
        });



        return rootView;
    }
}