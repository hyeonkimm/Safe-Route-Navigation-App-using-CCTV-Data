package com.gproject.safetydirections;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.gproject.safetydirections.databinding.ActivityMainBinding;
import com.skt.Tmap.TMapGpsManager;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapView;

import java.time.LocalDate;


public class MainActivity extends AppCompatActivity implements TMapGpsManager.onLocationChangedCallback {
    private ActivityMainBinding binding;
    public static Context context_main;

    private TMapView tMapView;
    private TMapGpsManager tMapGPS;

    private final int REQUEST_CODE_GPS = 100;

    RecentSearchDBHelper recentSearchDBHelper;
    BookmarkDBHelper bookmarkDBHelper;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        context_main = this;

        recentSearchDBHelper = new RecentSearchDBHelper(this);
        bookmarkDBHelper = new BookmarkDBHelper(this);

        tMapView = new TMapView(this);

        tMapView.setSKTMapApiKey( "" ); //키값 입력
        binding.linearLayoutTmap.addView( tMapView );

        //처음 세팅
        tMapView.setZoomLevel(15);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);
        tMapView.setTrackingMode(true);
        tMapView.setIconVisibility(true);

        tMapGPS = new TMapGpsManager(this);
        tMapGPS.setMinTime(1000);
        tMapGPS.setMinDistance(10);
        tMapGPS.setProvider(TMapGpsManager.GPS_PROVIDER);

        //위치권한 확인
        if(checkLocationPermissions()){
            if (checkLocationServicesStatus()) { //위치확인
                tMapGPS.OpenGps();
            }
        }

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);//기본 타이틀 제거

        binding.directionsBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (checkLocationPermissions()) { //위치권한확인
                    if (!checkLocationServicesStatus()) { //위치확인
                        showDialogForLocationServiceSetting(); //설정창 이동 물음
                    } else {
                        Intent intent = new Intent(getApplicationContext(), DirectionInputActivity.class);
                        MyPoint curPoint = new MyPoint("현재위치", tMapGPS.getLocation().getLatitude(), tMapGPS.getLocation().getLongitude());
                        intent.putExtra("curPoint", curPoint);
                        Log.d("메인", "현재 위도: " + Double.toString(curPoint.getLatitude()) + ", " + "현재 경도: " + Double.toString(curPoint.getLongitude()));
                        startActivity(intent);
                    }
                }
            }
        });

        binding.bellBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (checkLocationPermissions()) { //위치권한확인
                    if (!checkLocationServicesStatus()) { //위치확인
                        showDialogForLocationServiceSetting(); //설정창 이동 물음
                    } else {
                        Intent intent = new Intent(getApplicationContext(), BellActivity.class);
                        MyPoint curPoint = new MyPoint("현재위치", tMapGPS.getLocation().getLatitude(), tMapGPS.getLocation().getLongitude());
                        intent.putExtra("curPoint", curPoint);
                        startActivity(intent);
                    }
                }
            }
        });

        binding.currentLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (checkLocationPermissions()) { //위치권한확인
                    if (!checkLocationServicesStatus()) { //위치확인
                        showDialogForLocationServiceSetting(); //설정창 이동 물음
                    } else {
                        TMapPoint tMapPoint = tMapGPS.getLocation();
                        tMapView.setLocationPoint(tMapPoint.getLongitude(), tMapPoint.getLatitude());
                        tMapView.setCenterPoint(tMapPoint.getLongitude(), tMapPoint.getLatitude());
                    }
                }
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.setting: //환경설정 클릭시
                Intent intent = new Intent(getApplicationContext(), SettingActivity.class);
                startActivity(intent);
                break;
            case R.id.instruction: //도움말 클릭시
                AlertDialog.Builder helpBuilder = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("사용법")
                        .setMessage("도움말 입니다.")
                        .setPositiveButton("확인", null);
                helpBuilder.show();
                break;
        }
        return true;
    }

    public boolean checkLocationPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_GPS);
            return false;
        } else {
            return true;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            tMapGPS.OpenGps();
            Toast.makeText(this, "위치권한 승인", Toast.LENGTH_LONG).show();
        }  else {
            Toast.makeText(this, "위치권한 승인이 필요합니다", Toast.LENGTH_LONG).show();
        }
    }

    public boolean checkLocationServicesStatus() {
        //위치 활성화 확인
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private void showDialogForLocationServiceSetting() {
        AlertDialog.Builder gpsBuilder = new AlertDialog.Builder(MainActivity.this);
        gpsBuilder.setTitle("위치 서비스 비활성화");
        gpsBuilder.setMessage("기능을 사용하기 위해서는 위치 서비스가 필요합니다.\n"
                + "위치 설정을 수정하시겠습니까?");
        gpsBuilder.setCancelable(true);
        gpsBuilder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent callGPSSettingIntent
                        = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivityForResult(callGPSSettingIntent, REQUEST_CODE_GPS);
            }
        });
        gpsBuilder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        gpsBuilder.show();
    }

    @Override
    public void onLocationChange(Location location) {
        tMapView.setLocationPoint(location.getLongitude(), location.getLatitude());
        tMapView.setCenterPoint(location.getLongitude(), location.getLatitude());
    }
}