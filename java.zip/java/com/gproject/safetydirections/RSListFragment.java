package com.gproject.safetydirections;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class RSListFragment extends Fragment {

    Adapter adapter;
    private RecentSearchDBHelper recentSearchDBHelper;
    private BookmarkDBHelper bookmarkDBHelper;
    SQLiteDatabase rsDatabase;
    SQLiteDatabase bmDatabase;
    int intentNum = 0;

    public RSListFragment() {

    }

    public RSListFragment(int intentNum) {
        this.intentNum = intentNum;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        recentSearchDBHelper = new RecentSearchDBHelper(this.getContext());
        bookmarkDBHelper = new BookmarkDBHelper(this.getContext());
        rsDatabase = recentSearchDBHelper.getWritableDatabase();
        bmDatabase = bookmarkDBHelper.getWritableDatabase();

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_rs_list, container, false);

        RecyclerView recyclerView = rootView.findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new Adapter(5, new InnerClass());
        recyclerView.setAdapter(adapter);

        showList();
        return rootView;
    }

    public void showList() {
        adapter.startNew();

        if (rsDatabase != null) {
            String sql = "SELECT * FROM recentSearchTBL;";
            Cursor cursor = rsDatabase.rawQuery(sql, null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                double latitude = cursor.getDouble(2);
                double longitude = cursor.getDouble(3);
                int isBM = cursor.getInt(4);

                MyPointForDB point = new MyPointForDB(id, name, latitude, longitude, isBM);
                adapter.addItem(point);
            }
            cursor.close();
        }
    }

    public class InnerClass {
        public void clickBookMarkBtn(MyPointForDB item) {
            if (item.getIsBM() == 0) {
                rsDatabase.execSQL("update recentSearchTBL set isBM=1 where _id=" + item.getId() + ";");
                String sql = "INSERT INTO bookMarkTBL(name, latitude, longitude) VALUES(?, ?, ?)";
                Log.d("데이터베이스", "넣기 성공");
                Object[] params = {item.getName(), item.getLatitude(), item.getLongitude()};
                bmDatabase.execSQL(sql, params);
                showList();
            } else {
                rsDatabase.execSQL("update recentSearchTBL set isBM=0 where name='" + item.getName() + "' AND latitude=" + item.getLatitude() + " AND longitude=" + item.getLongitude() + ";");
                bmDatabase.execSQL("delete from bookMarkTBL where name='" + item.getName() + "' AND latitude=" + item.getLatitude() + " AND longitude=" + item.getLongitude() + ";");
                showList();
            }
        }

        public void setItemForIntent(MyPointForDB item) {
            recentSearchDBHelper.isDuplicated(item.getName(), item.getLatitude(), item.getLongitude());
            String sql = "INSERT INTO recentSearchTBL(name, latitude, longitude, isBM) VALUES(?, ?, ?, ?)";
            Object[] params = {item.getName(), item.getLatitude(), item.getLongitude(), item.getIsBM()};
            rsDatabase.execSQL(sql, params);

            if (intentNum == 10) {
                ((DirectionInputActivity) getActivity()).sendPointwithNum(item.getMyPoint());
            } else {
                ((DirectionChooseActivity) getActivity()).sendPoint(item.getMyPoint());
            }
        }

        public void clickDeleteBtn(MyPointForDB item) {
            rsDatabase.execSQL("delete from recentSearchTBL where _id=" + item.getId() + ";");
            adapter.removeItem(item);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}