package com.gproject.safetydirections;

import java.io.Serializable;

public class Cctv implements Serializable {
    private String institution;  //관리기관명
    private int count;           // 카메라 대수
    private String direction;    //촬영방면
    private double latitude;     //위도
    private double longitude;    //경도

    public Cctv() {

    }

    public Cctv(String institution, int count, String direction, double latitude, double longitude) {
        this.institution = institution;
        this.count = count;
        this.direction = direction;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getInstitution() {
        return institution;
    }

    public  void setInstitution(String institution){
        this.institution = institution;
    }

    public int getCount() {
        return count;
    }

    public  void setCount(int count){
        this.count = count;
    }

    public String getDirection() {
        return direction;
    }

    public  void setDirection(String direction){
        this.direction = direction;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public  void setLatitude(double latitude){
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
